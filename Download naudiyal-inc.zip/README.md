# Naudiyal Inc. – AI Solutions & Consulting

Built with Next.js 14 and Tailwind CSS. Includes lead capture modal, Calendly integration, and luxury branding.

## Setup
```bash
npm install
npm run dev
```

## Deploy
Push to GitHub and connect to Vercel for instant deployment.
